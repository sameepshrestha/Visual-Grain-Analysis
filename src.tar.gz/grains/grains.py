"""grains dataset."""

import tensorflow_datasets as tfds
from os.path import basename
import os

_DESCRIPTION = """
Unearthed  / CBH grains dataset
"""

class Grains(tfds.core.GeneratorBasedBuilder):
  """DatasetBuilder for grains dataset."""

  VERSION = tfds.core.Version('1.0.7')
  RELEASE_NOTES = {
      '1.0.7': 'max 500 samples per disease class and max 10000 samples per sound class',
  }
  MANUAL_DOWNLOAD_INSTRUCTIONS = 'copy train.zip, val.zip  to <home_dir>/tensorflow_datasets/downloads/manual/ or use --manual_dir arg when building tfds'
  LBL = dict(zip(['B_BSMUT1', 'B_CLEV5B', 'B_DISTO', 'B_GRMEND', 'B_HDBARL',
                  'B_PICKLD', 'B_SKINED', 'B_SOUND', 'B_SPRTED', 'B_SPTMLD',
                  'O_GROAT', 'O_HDOATS', 'O_SEPAFF', 'O_SOUND', 'O_SPOTMA',
                  'WD_RADPODS', 'WD_RYEGRASS', 'WD_SPEARGRASS', 'WD_WILDOATS',
                  'W_DISTO', 'W_FLDFUN', 'W_INSDA2', 'W_PICKLE', 'W_SEVERE',
                  'W_SOUND', 'W_SPROUT', 'W_STAIND', 'W_WHITEG'], range(28)))

  def _info(self) -> tfds.core.DatasetInfo:
    """Returns the dataset metadata."""
    return tfds.core.DatasetInfo(
        builder=self,
        description=_DESCRIPTION,
        features=tfds.features.FeaturesDict({

            'image': tfds.features.Image(shape=(224, 224, 3)),
            'label': tfds.features.ClassLabel(num_classes=28)
        }),
        supervised_keys=('image', 'label'),
        citation="",
    )

  def _split_generators(self, dl_manager: tfds.download.DownloadManager):
    """Returns SplitGenerators."""

    archive_path = dl_manager.manual_dir / 'train.zip'
    extracted_path_train = dl_manager.extract(archive_path)

    archive_path_val = dl_manager.manual_dir / 'val.zip'
    extracted_path_val = dl_manager.extract(archive_path_val)

    return {
        'train': self._generate_examples(extracted_path_train),
        'val': self._generate_examples(extracted_path_val),
    }

  def _generate_examples(self, path):
    """Yields examples."""
    for f in path.glob('**/*.png'):
         key = basename(f)
         lbl = basename(os.path.split(f)[0])
         yield key, {

                  'image': f,
                  'label': self.LBL[lbl],
         }



